#!/usr/bin/python

import sys
import os
import time

DATABASE = os.environ["DATAROOT"]
SEGMENT = int(os.environ["SEGMENT"])

# read the start time and end time
def load_time(segment):
    fp = open(DATABASE + "/seg" + str(segment) + "/raw/time")
    lines = fp.readlines();
    start_time = lines[0][8:10] + ":" + lines[0][10:12] + ":" + lines[0][12:14]
    end_time = lines[1][8:10] + ":" + lines[1][10:12] + ":" + lines[1][12:14]
    return [start_time, end_time]

if __name__ == "__main__":
    node = sys.argv[1]
    DEVICE = sys.argv[2]

    #print "Press enter to program node " + str(node)
    #sys.stdin.readline()
    cmd = "make telosb reinstall.0 bsl," + DEVICE
    print cmd
    os.system(cmd)

    #print "\n\n"
    print "Wait for erase done (green light on)."
    time.sleep(8)
    print "wake up"
    #print "Press enter to write data to node " + str(node) + " and test it"
    #sys.stdin.readline()
    [start_time, end_time] = load_time(SEGMENT)
    cmd = "java Download -c serial@" + DEVICE + ":telosb -m 0 -s seg" + str(SEGMENT) + " -n " + node + " -S " + start_time + " -E " + end_time
    print cmd
    os.system(cmd)

    #print "\n\n"
    #print "Press enter to re-write node " + str(node)
    #sys.stdin.readline()
    print "sleep for 2 seconds"
    time.sleep(2)
    print "wake up"
    cmd = "make telosb reinstall.1 bsl," + DEVICE
    print cmd
    os.system(cmd)

    #print "\n\n"
    #print "Press enter to test node " + str(node)
    #sys.stdin.readline()
    print "sleep for 2 seconds"
    time.sleep(2)
    print "wake up"
    cmd = "java Download -c serial@" + DEVICE + ":telosb -m 1 -s seg" + str(SEGMENT) + " -n " + node + " -S " + start_time + " -E " + end_time + " 1>mlog_" + str(node)
    print cmd
    if os.system(cmd) != 0:
        exit(1)

    exit(0)
