
#ifndef TEST_SERIAL_H
#define TEST_SERIAL_H

typedef nx_struct download_msg {
     nx_uint32_t rtime;
     nx_uint32_t len;
     nx_uint32_t has_next;
     nx_int32_t data[32];
} download_msg_t;

typedef nx_struct read_msg {
     nx_uint32_t dummy;
} read_msg_t;

enum {
  AM_DOWNLOAD_MSG = 9,
};

#endif
