import java.io.IOException;

import java.io.*;
import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;

import jargs.gnu.CmdLineParser;

public class Download implements MessageListener {

     //public static final String DATA_ROOT = "/work/dataset/St-Helens/data";
     public static final String DATA_ROOT = System.getenv().get("DATAROOT");
     public static final int SEND_PERIOD = 32; // in millisecond

     private MoteIF moteIF;
     private int startTime;
     private int endTime;
     private int rtime;
     private int currentTime;
     private boolean noMoreData;
     private BufferedReader br;
     public int reading;
     private int rbuf[];
     private int rbufCur;
     private boolean testFail;

     public static void printf(String msg) { System.err.println(msg); }

     public static int parseTime(String strTime) {
	  String[] parts = strTime.split(":");
	  return Integer.parseInt(parts[0]) * 3600 + Integer.parseInt(parts[1]) * 60 + Integer.parseInt(parts[2]);
     }

     public boolean initDataSource(String segment, int node, String startTime, String endTime) throws Exception {
	  this.startTime = parseTime(startTime);
	  this.endTime = parseTime(endTime);
	  currentTime = 0;
	  noMoreData = false;
	  printf("Loading: " + DATA_ROOT + "/" + segment + "/raw/" + (new PrintfFormat("N%02d_EHZ_WSV.csv")).sprintf(node));
	  FileInputStream fstream = new FileInputStream(DATA_ROOT + "/" + segment + "/raw/" + (new PrintfFormat("N%02d_EHZ_WSV.csv")).sprintf(node));
	  DataInputStream in = new DataInputStream(fstream);
	  br = new BufferedReader(new InputStreamReader(in));
	  String line;
	  while(true) {
	       if( (line = br.readLine()) == null) {
		    System.err.println("outor occurs on reading the data trace.");
		    System.exit(1);
	       }

	       String[] parts = line.split(" ")[1].split(",");
	       this.reading = Integer.parseInt(parts[1]);
	       String strTime = parts[0].substring(0,8);
	       rtime = parseTime(strTime);
	       if(rtime >= this.startTime) break;
	  }

	  //System.err.println(line);
	  if(rtime >= this.startTime) return true;
	  System.err.println("Fail to locate the start of the data trace.");
	  return false;
     }

     public boolean readNext() throws Exception{
	  String line;
	  if( (line = br.readLine()) == null) {
	       return false;
	  }

	  String[] parts = line.split(" ")[1].split(",");
	  this.reading = Integer.parseInt(parts[1]);
	  String strTime = parts[0].substring(0,8);
	  rtime = parseTime(strTime);
	  if(rtime >= this.endTime) {
	       return false;
	  }
	  return true;       
     }

     public int postBuffer(int[] buf) throws Exception {
	  int i = 0;
	  while(noMoreData == false && (rtime - startTime) == currentTime) {
	       buf[i++] = reading;
	       if(readNext() == false) {
		    noMoreData = true;
		    break;
	       }
	  }

	  currentTime = rtime - startTime;

	  if(noMoreData == true && i == 0) return -1;

	  return i;

     }
     
     public Download(MoteIF moteIF) {
	  this.rbuf = new int[128];
	  this.rbufCur = 0;
	  this.testFail = false;
	  this.moteIF = moteIF;
	  this.moteIF.registerListener(new DownloadMsg(), this);
     }
     
     public void sendPackets() throws Exception {
	  int counter = 0;
	  DownloadMsg payload = new DownloadMsg();

	  
	  int[] buf = new int[128];
	  int[] data = new int[32]; // the length of the packet that goes through the serial interface
	  int count = 0;
	  int j;

	  while( (count = postBuffer(buf)) != -1 ) {
	       
	       for(int i = 0; i < (count / 32 + 1); i++) {		    
		    for(j = 0; j < 32; j++) {
			 if( (i * 32 + j) >= count) break;
			 data[j] = buf[i * 32 + j];
		    }
		    payload.set_data(data);
		    payload.set_rtime(currentTime);
		    payload.set_len(j);
		    if(count > (i + 1)*32) payload.set_has_next(1);
		    else payload.set_has_next(0);

		    //printf("len=" + j);
		    //printf("currentTime=" + currentTime);
		    //printf("has_next=" + payload.get_has_next());

		    moteIF.send(0, payload);

		    Thread.sleep(SEND_PERIOD);
	       }

	       
	  }

	  // write an end block
	  payload.set_len(0);
	  moteIF.send(0, payload);
     }

     public void startRead() throws Exception {
	  ReadMsg payload = new ReadMsg();
	  moteIF.send(0, payload);
     }
     
     public void messageReceived(int to, Message message) {
	  DownloadMsg msg = (DownloadMsg) message;
	  int[] buf = new int[128];
	  int count = 0;

	  //System.err.println(msg.get_rtime() + " " + msg.get_len() + " " + msg.get_data()[0] + " " + msg.get_has_next());
	  for(int i = 0; i < msg.get_len(); i++) {
	       System.out.println(msg.get_data()[i]);
	       rbuf[rbufCur] = msg.get_data()[i];
	       rbufCur ++;
	  }

	  if(msg.get_has_next() == 0)
	  {
	       // check the data
	       try {
		    count = postBuffer(buf);
	       } catch(Exception ex)
	       {
		    System.err.println(ex);
	       }
	       if( count == -1 && rbufCur == 0) // over
	       {
		    if(testFail)
		    {
			 printf("Test is finished with errors.");
			 System.exit(1);
		    }
		    else
		    {
			 printf("test success.");
			 System.exit(0);
		    }
	       }
	       else if( count != rbufCur )
	       {
		    printf("Inconsistent block size");
		    testFail = true;
	       }
	       else
	       {
		    for(int j = 0; j < count; j++) {
			 if(buf[j] != rbuf[j]) {
			      printf("Inconsistent data.");
			      testFail = true;
			 }
		    }
	       }


	       rbufCur = 0;
	  }
     }

     public static void usage() {
	  System.err.println("Usage: java Download\n" + 
			     "[{-h, --help}]                                 display this message\n" +
			     "{-c, --comm} serial@/dev/ttyUSBx:telosb        set the link address\n" +
			     "{-m, --mode} 0/1                               0: write mode; 1: read mode\n" +
			     "{-s, --seg} segment                            set segment\n" +
			     "{-n, --node} nodeid                            set nodeid\n" +
			     "{-S, --start} startTime                        set start time\n" +
			     "{-E, --end} endTime                            set end time\n");
     }
     
     public static void main(String[] args) throws Exception {

	  CmdLineParser parser = new CmdLineParser();
	  CmdLineParser.Option opt_comm = parser.addStringOption('c', "comm");
	  CmdLineParser.Option opt_mode = parser.addIntegerOption('m', "mode");
	  CmdLineParser.Option opt_seg = parser.addStringOption('s', "seg");
	  CmdLineParser.Option opt_node = parser.addIntegerOption('n', "node");
	  CmdLineParser.Option opt_st = parser.addStringOption('S', "start");
	  CmdLineParser.Option opt_et = parser.addStringOption('E', "end");
	  CmdLineParser.Option opt_help = parser.addBooleanOption('h', "help");

	  try {
	       parser.parse(args);
	  }
	  catch(CmdLineParser.OptionException e) {
	       System.err.println(e.getMessage());
	       usage();
	       System.exit(1);
	  }

	  Boolean help = (Boolean) parser.getOptionValue(opt_help);
	  if(help != null && help == true) {
	       usage();
	       System.exit(0);
	  }

	  String source = (String) parser.getOptionValue(opt_comm);
	  Integer mode = (Integer) parser.getOptionValue(opt_mode);
	  String segment = (String) parser.getOptionValue(opt_seg);
	  Integer node = (Integer) parser.getOptionValue(opt_node);
	  String startTime = (String) parser.getOptionValue(opt_st);
	  String endTime = (String) parser.getOptionValue(opt_et);


	  if(source == null || mode == null || segment == null || node == null || startTime == null || endTime == null) {
	       System.err.println("missing options.");
	       usage();
	       System.exit(1);
	  }

	  PhoenixSource phoenix = BuildSource.makePhoenix(source, PrintStreamMessenger.err);
	  
	  MoteIF mif = new ReliableMoteIF(phoenix);
	  Download dl = new Download(mif);

	  //dl.initDataSource("seg7", 1, "10:15:00", "10:25:00");
	  //dl.initDataSource("seg7", 1, "10:15:00", "10:15:10");
	  dl.initDataSource(segment, node, startTime, endTime);
	  
	  if(mode == 0) {
	       dl.sendPackets();
	       printf("Done.");
	       System.exit(0);
	  }
	  
	  else if(mode == 1) {
	       dl.startRead();
	  }
     }
     
     
}
