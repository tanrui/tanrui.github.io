#ifndef VOLCANOMSG_H
#define VOLCANOMSG_H

#include "config.h"

enum {
     AM_VOLCANO_MSG = 6,
};

enum {
     MSG_PERF = 2,
     MSG_SEL = 3, // require the local sensors to make local decisions
     MSG_DECISION = 4, // local decision msg
     MSG_START = 11    // the start msg from basestation
};

// all-in-one message
typedef nx_struct volcano_msg {
     nx_uint8_t msg_type;
     nx_uint8_t node_id; // maximum support 255 nodes
     nx_uint32_t rtime;
     nx_uint8_t scale;
     nx_uint32_t selection;
     nx_uint8_t decision;

     // user fields for performance measurement
     nx_uint16_t user1;
     nx_uint16_t user2;
     nx_uint16_t user3;
     nx_uint32_t user4;
} volcano_msg_t;

#endif
