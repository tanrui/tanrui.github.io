make telosb reinstall.$1 bsl,/dev/ttyUSB1
