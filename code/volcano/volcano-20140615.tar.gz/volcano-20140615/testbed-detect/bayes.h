#ifndef BAYES_H
#define BAYES_H

#include "config.h"
#include "bayes_model.h"
#include "kiss_fft.h"

#define ITER_DIM(x) for(x = 0; x < FEATURE_DIM; x++)
#define ITER_SCALES(x) for(x = 0; x < MS_GAUSS_SCALES; x++)

int bandwidth = SAMPLING_RATE / FEATURE_DIM / 2;

void extract_feature(kiss_fft_scalar *data, float feature[FEATURE_DIM], kiss_fftr_cfg fft_cfg)
{
     // FFT
     kiss_fft_cpx outdata[SAMPLING_RATE/2 + 1];
     float spectrum[SAMPLING_RATE/2];
     float sum_energy = 0;
     int i;
     
     kiss_fftr(fft_cfg, data, outdata);
     // ignore the DC part
     for(i = 1; i <= SAMPLING_RATE/2; i++) {
	  spectrum[i-1] = outdata[i].r * outdata[i].r + outdata[i].i * outdata[i].i;
	  sum_energy += spectrum[i-1];
     }
     for(i = 0; i < SAMPLING_RATE/2; i++) {
	  //spectrum[i] /= sum_energy;
	  spectrum[i] = 100 * spectrum[i] / sum_energy; // unit is percentage
     }

     // extract the feature
     for(i = 0; i < FEATURE_DIM; i++) {
	  feature[i] = 0;
     }
     for(i = 0; i < SAMPLING_RATE/2; i++) {
	  feature[(int)(i / bandwidth)] += spectrum[i];
     }
};

/* Mahalanobis distance */
float mahalanobis_distance(float x[FEATURE_DIM], float m[FEATURE_DIM], float inverse_cov[FEATURE_DIM])
{
     float result = 0;
     int i;

     ITER_DIM(i) {
	  result += (x[i] - m[i]) * (x[i] - m[i]) * inverse_cov[i];
     }

     return result;
};

int gmodel_detect(ms_gauss_model *this, int scale, kiss_fft_scalar *data, uint16_t count, kiss_fftr_cfg fft_cfg)
{
     float feature[FEATURE_DIM];
     float d0, d1;

     if(this->nsample[scale] < STAT_SIGNIFICANCE) {
	  //fprintf(stderr, "Warning - Node %d: insignificant distribution for hypothesis testing\n", TOS_NODE_ID);
	  return 0;
     }

     extract_feature(data, feature, fft_cfg);

     d0 = lnP0 - 0.5 * this->h0_ln_det - 0.5 * mahalanobis_distance(feature, this->h0_mean, this->h0_inverse_cov);
     d1 = lnP1 - 0.5 * this->ln_det[scale] - 0.5 * mahalanobis_distance(feature, this->mean[scale], this->inverse_cov[scale]);

     if(d1 > d0) return 1;
     return 0;
}


#endif

