import java.io.*;
import java.util.*;
import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;

public class FusionCenter implements MessageListener {

     class SensorPerf {
	  short node_id;
	  short scale;
	  float pf;
	  float pd;
     }

     class PerfMsgCollection {
	  long sensor_rtime;
	  Vector<VolcanoMsg> msgs;

	  public PerfMsgCollection(long rtime, VolcanoMsg msg) {
	       sensor_rtime = rtime;
	       msgs = new Vector<VolcanoMsg>();
	       msgs.add(msg);
	  }
     }

     class DecisionFusion {
	  long sensor_rtime;
	  short sum; // sum of local decisions
	  short negative_sum;
	  short solution_size; // the size of solution
	  short eta; // detection threshold

	  public DecisionFusion(long rtime, short solution_size, short eta) {
	       this.sensor_rtime = rtime;
	       this.solution_size = solution_size;
	       this.sum = 0;
	       this.negative_sum = 0;
	       this.eta = eta;
	  }

	  /* 1: positive system decision
	     0: negative system decision
	     -1: needs more local decisions
	  */
	  public int update(short decision) {
	       sum += decision;
	       negative_sum += (1 - decision);

	       if(sum > eta) {
		    return 1;
	       }
	       if(negative_sum >= (solution_size - eta)) {
		    return 0;
	       }
	       return -1;
	  }
     }     
     
     public static final short MSG_PERF = 2;
     public static final short MSG_SEL = 3;
     public static final short MSG_DECISION = 4;
     public static final short MSG_START = 11;
     public static final String MODEL_FOLDER = "../testbed-config/models";
     public static final String SELECT_WRAPPER = "./select_wrapper";
     public static final short NODES[] = {1, 2, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14};
     public static final long TX_SPREAD_TIME = 150; // 150 milliseconds are used to spread the tx to sensors, in order to avoid the collision when sensors get back to the base station


     /* performance measurement */
     public static final float cpuCurrent = 1.8f; // mA
     public static final float txCurrent = 17.4f; // mA
     public static final float rxCurrent = 19.7f; // mA
     public static final float txTime = 9; // ms, the time for tx a default TOS message (28byte payload) on TelosB
     public static final float rxTime = 9;

     public static final int surveilNode = 11;

     public float nodeEnergyTrace[];
     public long totalTxPackets = 0;
     public long totalRxPackets = 0;
     public long totalPreprocessTime = 0;
     public long totalPreprocessCnt = 0;
     public long totalEnergyTime = 0;
     public long totalEnergyCnt = 0;
     public long totalBufferTime = 0;
     public long totalBufferCnt = 0;
     public long totalDetectTime = 0;
     public long totalDetectCnt = 0;

     public static void debug(String s) { System.out.println(s); }
     public static void error(String s) { System.err.println(s); }

     private MoteIF moteIF;
     private short aliveSensor[];
     private long startRtime;
     private long endRtime;
     private long samplingPeriod;
     private Vector<PerfMsgCollection> receivedPerf;
     private Vector<PerfMsgCollection> workingPerf;     
     private Vector<SensorPerf> allPerf;
     private Vector<String> selectWrapperFeed;
     private Vector<DecisionFusion> fusion;
     private long sensorRtime;

     private void loadPerfModel() throws Exception {
	  for(short i : NODES) {
	       DataInputStream in = new DataInputStream(new FileInputStream(MODEL_FOLDER + "/b-dis-n" + i + ".txt"));
	       BufferedReader br = new BufferedReader(new InputStreamReader(in));
	       String line;
	       while( (line = br.readLine()) != null) {
		    String[] meta = line.split("\t");
		    SensorPerf perf = new SensorPerf();
		    perf.node_id = i;
		    perf.scale = Short.parseShort(meta[0]);
		    perf.pf = Float.parseFloat(meta[2]) / 100;
		    perf.pd = Float.parseFloat(meta[3]) / 100;
		    allPerf.add(perf);
	       }
	       in.close();
	  }
     }

     public FusionCenter(MoteIF moteIF, short aliveSensor[], long startRtime, long endRtime, long samplingPeriod) throws Exception {
	  this.moteIF = moteIF;
	  this.aliveSensor = aliveSensor;
	  this.startRtime = startRtime;
	  this.endRtime = endRtime;
	  this.nodeEnergyTrace = new float[(int)(endRtime - startRtime + 10)];
	  for(int i = 0; i < nodeEnergyTrace.length; i++) nodeEnergyTrace[i] = 0;	  
	  this.samplingPeriod = samplingPeriod;
	  sensorRtime = 0;
	  receivedPerf = new Vector<PerfMsgCollection>();
	  workingPerf = new Vector<PerfMsgCollection>();
	  allPerf = new Vector<SensorPerf>();
	  selectWrapperFeed = new Vector<String>();
	  fusion = new Vector<DecisionFusion>();
	  loadPerfModel();
	  this.moteIF.registerListener(new VolcanoMsg(), this);
     }

     public void start() throws Exception {
	  VolcanoMsg msg = new VolcanoMsg();
	  msg.set_msg_type(MSG_START);
	  msg.set_rtime(startRtime);
	  msg.set_selection(endRtime);
	  msg.set_user4(samplingPeriod);
	  long sleepInterval = TX_SPREAD_TIME / aliveSensor.length;
	  for(short i : aliveSensor) {
	       moteIF.send(i, msg);
	       Thread.sleep(sleepInterval);
	  }
     }

     public void select(long sensor_rtime, Vector<VolcanoMsg> received_perf) {
	  selectWrapperFeed.clear();			 
	  for(VolcanoMsg y : received_perf) {
	       for(SensorPerf x : allPerf) {
		    if(y.get_node_id() == x.node_id && y.get_scale() == x.scale) {
			 //debug(sensor_rtime + " : " + x.node_id + " " + x.scale + " " + x.pf + " " + x.pd);
			 selectWrapperFeed.add(x.node_id + "\t" + x.scale + "\t" + x.pf + "\t" + x.pd);
		    }
	       }
	  }
	  if(selectWrapperFeed.size() != 0) {
	       long diag_start = System.currentTimeMillis();
	       try
	       {
		    Process p = Runtime.getRuntime().exec(SELECT_WRAPPER);
		    PrintWriter stdOut = new PrintWriter(p.getOutputStream());
		    BufferedReader stdIn = new BufferedReader(new InputStreamReader(p.getInputStream()));
		    for(String feed : selectWrapperFeed) {
			 stdOut.println(feed);
		    }
		    stdOut.flush();
		    stdOut.close();
		    if(Integer.parseInt(stdIn.readLine()) == 1) {
			 // has solution
			 short eta = Short.parseShort(stdIn.readLine());
			 String strSolution = stdIn.readLine();
			 long solution = Long.parseLong(stdIn.readLine());			 
			 debug("BS@" + sensor_rtime + " : solution=" + strSolution);
			 debug("BS@" + sensor_rtime + " : eta=" + eta);
			 //debug(sensor_rtime + " : solution=" + solution);
			 String[] strSelection = strSolution.split(",");

			 // save the solution
			 fusion.add(new DecisionFusion(sensor_rtime, (short)strSelection.length, eta));

			 // send out solution
			 VolcanoMsg solMsg = new VolcanoMsg();
			 solMsg.set_msg_type(MSG_SEL);
			 solMsg.set_rtime(sensor_rtime);
			 solMsg.set_selection(solution);

			 // when measure the performance, we assume all sensors needs to receive the solution
			 totalRxPackets += aliveSensor.length;
			 nodeEnergyTrace[(int)(sensor_rtime - startRtime)] += rxCurrent * rxTime;

			 for(String strID : strSelection) {
			      moteIF.send(Integer.parseInt(strID), solMsg);
			      Thread.sleep(TX_SPREAD_TIME / strSelection.length);
			 }
			 //moteIF.send(MoteIF.TOS_BCAST_ADDR, solMsg);
		    }
		    else {
			 // no solution
			 debug("BS@" + sensor_rtime + " : no solution");
		    }
		    p.waitFor();
	       } catch(Exception ex) {
		    ex.printStackTrace();
	       }
	       //debug("selection consumes " + (System.currentTimeMillis() - diag_start));
	  }	  
     }

     public void reportPerformance() {

	  try {
	       PrintStream nodeConsumption = new PrintStream(new FileOutputStream("node" + surveilNode + "-consump.txt"));
	       debug("## node" + surveilNode + " consumption ##");
	       for(int i = 0; i < (endRtime - startRtime); i++) {
		    nodeConsumption.println(nodeEnergyTrace[i] / 1000);
		    debug(nodeEnergyTrace[i] / 1000 + "");
	       }
	       nodeConsumption.flush();
	       nodeConsumption.close();
	       
	       PrintStream totalConsumption = new PrintStream(new FileOutputStream("total-consump.txt"));
	       debug("## total consumption ##");
	       totalConsumption.print(totalTxPackets * txCurrent * rxTime / 1000);
	       totalConsumption.print("\t");
	       debug("tx: " + totalTxPackets * txCurrent * rxTime / 1000);
	       totalConsumption.print(totalRxPackets * rxCurrent * rxTime / 1000);
	       totalConsumption.print("\t");
	       debug("rx: " + totalRxPackets * rxCurrent * rxTime / 1000);
	       totalConsumption.print(totalPreprocessTime * cpuCurrent / 1000);
	       totalConsumption.print("\t");
	       debug("preprocess: " + totalPreprocessTime * cpuCurrent / 1000);
	       totalConsumption.print(totalEnergyTime * cpuCurrent / 1000);
	       totalConsumption.print("\t");
	       debug("energy: " + totalEnergyTime * cpuCurrent / 1000);
	       totalConsumption.print(totalBufferTime * cpuCurrent / 1000);
	       totalConsumption.print("\t");
	       debug("buffer: " + totalBufferTime * cpuCurrent / 1000);
	       totalConsumption.print(totalDetectTime * cpuCurrent / 1000);
	       totalConsumption.print("\n");
	       debug("bayes: " + totalDetectTime * cpuCurrent / 1000);
	       
	       totalConsumption.flush();
	       totalConsumption.close();

	       PrintStream avgTime = new PrintStream(new FileOutputStream("avg-time.txt"));
	       debug("## average time ##");

	       debug( ((float) totalPreprocessTime) / totalPreprocessCnt + "");
	       debug( ((float) totalEnergyTime) / totalEnergyCnt + "");
	       debug( ((float) totalBufferTime) / totalBufferCnt + "");
	       debug( ((float) totalDetectTime) / totalDetectCnt + "");

	       avgTime.println( ((float) totalPreprocessTime) / totalPreprocessCnt);
	       avgTime.println( ((float) totalEnergyTime) / totalEnergyCnt);
	       avgTime.println( ((float) totalBufferTime) / totalBufferCnt);
	       avgTime.println( ((float) totalDetectTime) / totalDetectCnt);

	       avgTime.flush();
	       avgTime.close();

	  }
	  catch(Exception ex) {
	       error(ex.getMessage());
	  }

	  System.exit(0);
     }

     public void messageReceived(int to, Message message) {
	  VolcanoMsg msg = (VolcanoMsg) message;
	  
	  /* the perf packet with scale=0 is not counted. In our system, a sensor with scale=0 will not
	     be selected. In practice, if sensor's scale=0, it can skip transmitting the perf message.
	     However, the CPU time should be counted.
	  */
	  if(msg.get_msg_type() == MSG_DECISION || (msg.get_msg_type() == MSG_PERF && msg.get_scale() != 0)) {
	       totalTxPackets ++;
	       if(msg.get_node_id() == surveilNode)
	       {
		    nodeEnergyTrace[(int)(msg.get_rtime() - startRtime)] += txCurrent * txTime;
	       }
	  }
	  
	  //debug("Node" + msg.get_node_id() + ": " + msg.get_rtime());
	  if(msg.get_msg_type() == MSG_PERF) {
	       //debug("Node" + msg.get_node_id() + ": user1=" + msg.get_user1() + ", user2=" + msg.get_user2() + ", user3=" + msg.get_user3());
	       //if(msg.get_node_id() == 1) error(msg.get_rtime() + "\t" + msg.get_user4());
	       //error("Node" + msg.get_node_id() + " @ " + msg.get_rtime() + " = " + msg.get_scale());
	       	       
	       if(msg.get_node_id() == surveilNode)
	       {		    
		    nodeEnergyTrace[(int)(msg.get_rtime() - startRtime)] += cpuCurrent * (msg.get_user1() + msg.get_user2() + msg.get_user3());
	       }

	       totalPreprocessTime += msg.get_user1();
	       totalPreprocessCnt ++;
	       totalEnergyTime += msg.get_user2();
	       totalEnergyCnt ++;
	       totalBufferTime += msg.get_user3();	       
	       totalBufferCnt ++;

	       // find the entry in receivedPerf that corresponds to msg.get_rtime()
	       boolean perfExists = false;
	       for(PerfMsgCollection col : receivedPerf) {
		    if(col.sensor_rtime == msg.get_rtime()) {
			 perfExists = true;
			 col.msgs.add(msg);
			 break;
		    }
	       }
	       if(!perfExists) {
		    PerfMsgCollection col = new PerfMsgCollection(msg.get_rtime(), msg);
		    receivedPerf.add(col);
	       }

	       // scan the receivedPerf
	       workingPerf.clear();
	       for(PerfMsgCollection col : receivedPerf) {
		    if(col.msgs.size() >= aliveSensor.length) {
			 // search the previous collections with missing perf msgs
			 for(PerfMsgCollection col0 : receivedPerf) {
			      if( col0.sensor_rtime < col.sensor_rtime) {
				   debug("perf collection with missing msgs detected @ " + col0.sensor_rtime + " with " + col0.msgs.size() + " msgs.");
				   workingPerf.add(col0);			      
			      }
			 }
			 workingPerf.add(col);
		    }
	       }
	       for(PerfMsgCollection col : workingPerf) {
		    select(col.sensor_rtime, col.msgs);
		    receivedPerf.remove(col);
		    if(col.sensor_rtime == endRtime) {
			 reportPerformance();
		    }
	       }
	  }
	  else if(msg.get_msg_type() == MSG_DECISION) {
	       if(msg.get_user2() == 0) {
		    debug("\tNode" + msg.get_node_id() + "@" + msg.get_rtime() + " hasn't finished the detection in previous slot. Skipping.");
	       }
	       else {		    
		    debug("\tNode" + msg.get_node_id() + "@" + msg.get_rtime() + " decides " + msg.get_decision() + " FFT time=" + msg.get_user1());
		    if(msg.get_node_id() == surveilNode) {
			 nodeEnergyTrace[(int)(msg.get_rtime() - startRtime)] += cpuCurrent * msg.get_user1();
		    }
		    totalDetectTime += msg.get_user1();
		    totalDetectCnt ++;
		    //debug("The Bayesian detection consumes " + msg.get_user1());
		    
		    // find the entry in fusion that corresponds to msg.get_rtime()
		    DecisionFusion deleteEntry = null;
		    for(DecisionFusion df : fusion) {
			 if(df.sensor_rtime == msg.get_rtime()) {
			      switch(df.update(msg.get_decision()))
			      {
			      case 1: // positive system decision
				   debug("BS@" + msg.get_rtime() + " : system decision 1");
				   error(msg.get_rtime() + "");
				   deleteEntry = df;
				   break;
			      case 0: // negative system decision
				   debug("BS@" + msg.get_rtime() + " : system decision 0");
				   deleteEntry = df;
				   break;
			      }
			 }
		    }
		    if(deleteEntry != null) fusion.remove(deleteEntry);
	       }
	  }
     }

     public static void main(String[] args) throws Exception {

	  // configuration
	  String source = "serial@/dev/ttyUSB0:telosb";
	  short sensors[] = {1, 2, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14};
	  long startRtime = 0;
	  long endRtime = 598;
	  long samplingPeriod = 1000;
	  // config end

	  PhoenixSource phoenix = BuildSource.makePhoenix(source, PrintStreamMessenger.err);
	  MoteIF moteIF = new MoteIF(phoenix);
	  FusionCenter fc = new FusionCenter(moteIF, sensors, startRtime, endRtime, samplingPeriod);
	  fc.start();
     }
}
