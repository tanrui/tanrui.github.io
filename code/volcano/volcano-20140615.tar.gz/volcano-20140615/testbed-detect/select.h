#ifndef SELECT_H
#define SELECT_H

//#define ALPHA 1e-6 // upper bound of system false alarm rate
//#define IQ_ALPHA 4.753424
//#define BETA (1-1e-6) // lower bound of system detection probability
//#define IQ_BETA -4.753424
//#define EPSILON 0.01 // upper bound of minimax error rate

float ALPHA = 1e-6;
float IQ_ALPHA = 4.753424;
float BETA = (1-1e-6);
float IQ_BETA = -4.753424;

#define CRITICAL_N 10

typedef struct sperf_ // sensor performance
{
     uint16_t id; // sensor ID
     uint8_t scale; // energy scale
     float pf; // local PF
     float pd; // local PD
     float metric; // user defined metric
} sperf;

/*
	next_comb(int comb[], int k, int n)
		Generates the next combination of n elements as k after comb

	comb => the previous combination ( use (0, 1, 2, ..., k) for first)
	k => the size of the subsets to generate
	n => the size of the original set

	Returns: 1 if a valid combination was found
		0, otherwise
*/
int next_comb(int *comb, int k, int n) {
	int i = k - 1;
	++comb[i];
	while ((i > 0) && (comb[i] >= n - k + 1 + i)) {
		--i;
		++comb[i];
	}

	if (comb[0] > n - k) /* Combination (n-k, n-k+1, ..., n) reached */
		return 0; /* No more combinations can be generated */

	/* comb now looks like (..., x, n, n, n, ..., n).
	Turn it into (..., x, x + 1, x + 2, ...) */
	for (i = i + 1; i < k; ++i)
		comb[i] = comb[i - 1] + 1;

	return 1;
};

void complement(int *comb, int *complement, int *work, int k, int n)
{
     int i, cur;

     for(i = 0; i < n; i++)
     {
	  work[i] = 0;
     }
     for(i = 0; i < k; i++)
     {
	  work[comb[i]] = 1;
     }
     cur = 0;
     for(i = 0; i < n; i++)
     {
	  if(work[i] == 0) complement[cur++] = i;
     }
};

void generalized_binomial_pdf(int n,
			      float *p, // success probabilities
			      float *pdf // output, the length of the space is n+1
     )
{
     static int comb[NSENSOR];
     static int comp[NSENSOR]; // complement set of comb
     static int work[NSENSOR];
     float tmp;
     int k, i;
     
     for(k = 1; k < n; k++)
     {
	  // n choose k
	  pdf[k] = 0;
	  // first combination
	  for(i = 0; i < k; i++) comb[i] = i;
	  complement(comb, comp, work, k, n);
	  tmp = 1;
	  for(i = 0; i < k; i++) tmp *= p[comb[i]];
	  for(i = 0; i < (n-k); i++) tmp *= (1.0 - p[comp[i]]);
	  pdf[k] += tmp;

	  while(next_comb(comb, k, n))
	  {
	       complement(comb, comp, work, k, n);
	       tmp = 1;
	       for(i = 0; i < k; i++) tmp *= p[comb[i]];
	       for(i = 0; i < (n-k); i++) tmp *= (1.0 - p[comp[i]]);
	       pdf[k] += tmp;
	  }
     }
     // n choose 0
     pdf[0] = 1;
     for(i = 0; i < n; i++) pdf[0] *= (1.0 - p[i]);

     // n choose n
     pdf[n] = 1;
     for(i = 0; i < n; i++) pdf[n] *= p[i];
};

void generalized_binomial_cdf(int n,
			      float *p,
			      float *cdf // output
     )
{
     static float pdf[NSENSOR];
     int i, j;

     generalized_binomial_pdf(n, p, pdf);

     for(i = 0; i <= n; i++)
     {
	  cdf[i] = 0;
	  for(j = 0; j <= i; j++)
	  {
	       cdf[i] += pdf[j];
	  }
     }
};

int brutal_force_unit_solve(sperf *z, int N, // input information
			    int k, // selected number
			    uint8_t *solution, // solution stored in an array
			    uint8_t *n, // length of solution
			    uint8_t *eta // optimal threshold
     )
{
     float pf[NSENSOR], pd[NSENSOR], h0_cdf[NSENSOR+1], h1_cdf[NSENSOR+1];
     int comb[NSENSOR];
     bool eta_found;
     int i;

     // choose k sensors
	  
     // first combination
     for(i = 0; i < k; i++) comb[i] = i;
     for(i = 0; i < k; i++)
     {
	  pf[i] = z[comb[i]].pf;
	  pd[i] = z[comb[i]].pd;
     }
     generalized_binomial_cdf(k, pf, h0_cdf);
     // determine threshold ...
     eta_found = FALSE;
     for((*eta) = 0; (*eta) <= k; (*eta)++)
     {
	  if(h0_cdf[*eta] > (1.0 - ALPHA))
	  {
	       eta_found = TRUE;
	       break;
	  }
     }
     if(eta_found)
     {
	  generalized_binomial_cdf(k, pd, h1_cdf);
	  if(h1_cdf[*eta] < (1.0 - BETA))
	  {
	       // solution found
	       //printf("eta=%d\n", eta);
	       for(i = 0; i < k; i++)
	       {
		    solution[i] = z[comb[i]].id;
		    //printf("%d\t%f\t%f\n", z[comb[i]].id, z[comb[i]].pf, z[comb[i]].pd);
	       }
	       *n = k;
	       return 1;
	  }
     }
     
     
     while(next_comb(comb, k, N))
     {
	  for(i = 0; i < k; i++)
	  {
	       pf[i] = z[comb[i]].pf;
	       pd[i] = z[comb[i]].pd;
	  }
	  generalized_binomial_cdf(k, pf, h0_cdf);
	  // determine threshold ...
	  eta_found = FALSE;
	  for((*eta) = 0; (*eta) <= k; (*eta)++)
	  {
	       if(h0_cdf[*eta] > (1.0 - ALPHA))
	       {
		    eta_found = TRUE;
		    break;
	       }
	  }
	  if(eta_found)
	  {
	       generalized_binomial_cdf(k, pd, h1_cdf);
	       if(h1_cdf[*eta] < (1.0 - BETA))
	       {
		    // solution found
		    // printf("eta=%d\n", eta);
		    for(i = 0; i < k; i++)
		    {
			 solution[i] = z[comb[i]].id;
			 //printf("%d\t%f\t%f\n", z[comb[i]].id, z[comb[i]].pf, z[comb[i]].pd);
		    }
		    *n = k;
		    return 1;
	       }
	  }
     }

     return 0;
}

int brutal_force_solver(sperf *z, int N, // input information
			uint8_t *solution, // solution stored in an array
			uint8_t *n, // length of solution
			uint8_t *eta // optimal threshold
     )
{
     int k;

     for(k = 1; k < N; k++)
     {
	  if(brutal_force_unit_solve(z, N, k, solution, n, eta) == 1) return 1;
     }

     // no solution
     return 0;
};


void bubble_sort(sperf *z, int N)
{
     int i, j;
     sperf tmp;

     for(i = (N-1); i >= 0; i--)
     {
	  for(j = 1; j <= i; j++)
	  {
	       if(z[j-1].metric > z[j].metric)
	       {
		    tmp = z[j-1];
		    z[j-1] = z[j];
		    z[j] = tmp;
	       }
	  }
     }
};

int approximate_solver(sperf *z, int N, // input information
			uint8_t *solution, // solution stored in an array
			uint8_t *n, // length of solution
			uint8_t *eta // optimal threshold
     )
{
     int i, j;
     float f1;
     float tmp1, tmp2, tmp3;
     
     // compute the metric
     for(i = 0; i < N; i++)
     {
	  z[i].metric = z[i].pf - z[i].pd;
     }
     bubble_sort(z, N);

     // check single one sensor solution
     if( z[0].pf < ALPHA && z[0].pd > BETA)
     {
	  //float pf[NSENSOR], pd[NSENSOR], h0_cdf[NSENSOR+1], h1_cdf[NSENSOR+1];
	  //pf[0] = z[i].pf;
	  //pd[0] = z[i].pd;
	  //generalized_binomial_cdf(1, pf, h0_cdf);
	  //generalized_binomial_cdf(1, pd, h1_cdf);
	  //printf("h0_cdf: %e, %e\n", h0_cdf[0], h0_cdf[1]);
	  //printf("h1_cdf: %e, %e\n", h1_cdf[0], h1_cdf[1]);
	  solution[0] = z[0].id;
	  *n = 1;
	  //*eta = 0;
	  return 1;
     }

     if(N == 1) return 0;

     tmp1 = (z[0].pf - z[0].pf * z[0].pf);
     tmp2 = (z[0].pf - z[0].pd);
     tmp3 = (z[0].pd - z[0].pd * z[0].pd);

     for(i = 1; i < N; i++)
     {
	  tmp1 += (z[i].pf - z[i].pf * z[i].pf);
	  tmp2 += (z[i].pf - z[i].pd);
	  tmp3 += (z[i].pd - z[i].pd * z[i].pd);
	  f1 = (IQ_ALPHA * sqrt(tmp1) + tmp2) / sqrt(tmp3);
	  if(f1 < IQ_BETA)
	  {
	       // solution found
	       for(j = 0; j <= i; j++)
	       {
		    //printf("%d,", z[j].id);
		    solution[j] = z[j].id;
		    //printf("sensor %d, pf=%f, pd=%f, f1=%f, iqbeta=%f\n", z[j].id, z[j].pf, z[j].pd, f1, IQ_BETA);
	       }
	       *n = i + 1;
	       return 1;
	  }
     }

     // no solution
     return 0;
};

int hybrid_solver(sperf *z, int N, // input information
		  uint8_t *solution, // solution stored in an array
		  uint8_t *n, // length of solution
		  uint8_t *eta // optimal threshold
     )
{
     int i, j, k;
     float f1;
     float tmp1, tmp2, tmp3;

     for(i = 0; i < N; i++)
     {
	  z[i].metric = z[i].pf - z[i].pd;
     }
     bubble_sort(z, N);

     if(N < CRITICAL_N)
     {
	  for(k = 1; k <= N; k++)
	  {
	       if(brutal_force_unit_solve(z, N, k, solution, n, eta) == 1) return 1;
	  }
	  return 0;
     }
     else
     {
	  for(k = 1; k < CRITICAL_N; k++)
	  {
	       if(brutal_force_unit_solve(z, N, k, solution, n, eta) == 1) return 1;
	  }
	  
	  tmp1 = 0;
	  tmp2 = 0;
	  tmp3 = 0;
	  for(i = 0; i < N; i++)
	  {
	       tmp1 += (z[i].pf - z[i].pf * z[i].pf);
	       tmp2 += (z[i].pf - z[i].pd);
	       tmp3 += (z[i].pd - z[i].pd * z[i].pd);
	       
	       if((i+1) >= CRITICAL_N)
	       {
		    f1 = (IQ_ALPHA * sqrt(tmp1) + tmp2) / sqrt(tmp3);
		    if(f1 < IQ_BETA)
		    {
			 // solution found
			 tmp2 = 0;
			 for(j = 0; j <= i; j++)
			 {
			      //printf("%d,", z[j].id);
			      solution[j] = z[j].id;
			      tmp2 += z[j].pf;
			 }
			 tmp2 += IQ_ALPHA * sqrt(tmp1);
			 *eta = (uint8_t) tmp2;
			 *n = i + 1;
			 return 1;
		    }
	       }
	  }
     }

     return 0;
};

#endif
