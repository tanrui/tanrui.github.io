#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdbool.h>
#include <math.h>
#include "config.h"

#ifndef TRUE
#define TRUE true
#endif

#ifndef FALSE
#define FALSE true
#endif

#include "select.h"



int main(int argc, char *argv[])
{
     sperf received_perf[NSENSOR];
     uint8_t select_solution[NSENSOR];
     uint8_t solution_size;
     int cur = 0;
     uint8_t eta;
     int i;
     int node_id;
     int scale;
     uint32_t encoded_solution = 0;

     while( fscanf(stdin, "%d\t%d\t%f\t%f", &node_id,
		   &scale,
		   &received_perf[cur].pf,
		   &received_perf[cur].pd) != EOF )
     {
	  received_perf[cur].id = node_id;
	  received_perf[cur].scale = scale;
	  cur ++;
     }

     if(hybrid_solver(received_perf, cur, select_solution, &solution_size, &eta))
     {	  
	  printf("1\n");
	  printf("%d\n", eta);
	  for(i = 0; i < (solution_size-1); i++)
	  {
	       printf("%d,", select_solution[i]);
	       encoded_solution += 1 << (select_solution[i] - 1);
	  }
	  printf("%d\n", select_solution[solution_size-1]);
	  encoded_solution += 1 << (select_solution[solution_size-1] - 1);

	  printf("%d\n", encoded_solution);
     }
     else
     {
	  printf("0\n");
     }

     fflush(stdout);
     
     return 0;
};
