#ifndef ENERGY_H
#define ENERGY_H

#include "config.h"
#include <math.h>

float seismic_energy(const float *data, /* the data after mean removal */
		     const int32_t *raw_data, /* the data before mean removal */
		     uint16_t data_len, /* length of data */
		     uint16_t valid_count)
{
     float mean;
     uint16_t count = 0;
     uint16_t i;

     if(valid_count == 0) return 0;

     for(i = 0; i < data_len; i++)
     {
	  if(raw_data[i] != INVALID_MEASUREMENT)
	  {
	       mean = data[i] * data[i];
	       count = 1;
	       i++;
	       break;
	  }
     }
     while(i < data_len)
     {
	  if(raw_data[i] != INVALID_MEASUREMENT)
	  {
	       mean = ((float) count) / (count + 1) * mean + (data[i] * data[i]) / (count + 1);
	       count ++;
	  }
	  i++;
     }

     return mean;
};

/* the integer version of seismic energy algorithm */
uint32_t integer_seismic_energy(const int32_t *data, /* the data after mean removal */
			       const int32_t *raw_data, /* the data before mean removal */
			       uint16_t data_len, /* length of data */
			       uint16_t valid_count)
{
     uint32_t sum_sq = 0;
     uint16_t i;

     if(valid_count == 0) return 0;

     for(i = 0; i < data_len; i++)
     {
	  if(raw_data[i] != INVALID_MEASUREMENT)
	  {
	       sum_sq += data[i] * data[i];
	  }
     }
     return sum_sq / valid_count;
};

uint32_t possible_scales[8] = {10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000};

int energy_scale(float energy)
{
     //return (int) log10(energy);
     int i;

     for(i = 0; i < 8; i++) {
	  if (energy < possible_scales[i]) return i;
     }

     return 8;     
};

/* the integer version of energy scale algorithm */
uint8_t integer_energy_scale(uint32_t energy)
{
     uint8_t i;
     for(i = 0; i < 8; i++) {
	  if(energy < possible_scales[i]) return i;
     }

     return 8;
};


#endif
