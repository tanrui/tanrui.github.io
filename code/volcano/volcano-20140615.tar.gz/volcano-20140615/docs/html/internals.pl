# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/cite_tan2010quality/;
$ref_files{$key} = "$dir".q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_misc1/;
$ref_files{$key} = "$dir".q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_song2009air/;
$ref_files{$key} = "$dir".q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tan2013fusion/;
$ref_files{$key} = "$dir".q|volcano-code.html|; 
$noresave{$key} = "$nosave";

1;

