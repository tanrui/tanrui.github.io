# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/cite_tan2010quality/;
$external_labels{$key} = "$URL/" . q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_misc1/;
$external_labels{$key} = "$URL/" . q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_song2009air/;
$external_labels{$key} = "$URL/" . q|volcano-code.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tan2013fusion/;
$external_labels{$key} = "$URL/" . q|volcano-code.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


1;

