#ifndef CONFIG_MSG_H
#define CONFIG_MSG_H

typedef nx_struct config_msg {
     nx_uint32_t x;
     nx_int32_t y;
} config_msg_t;

typedef nx_struct read_msg {
     nx_uint32_t dummy;
} read_msg_t;

enum {
     AM_CONFIG_MSG = 10,
};

#endif
