#!/usr/bin/python

import sys
import os
import time

if __name__ == "__main__":
    node = sys.argv[1]
    DEVICE = sys.argv[2]

    #print "Press enter to program node " + str(node)
    #sys.stdin.readline()
    cmd = "make telosb reinstall.0 bsl," + DEVICE
    print cmd
    os.system(cmd)

    #print "\n\n"
    print "Wait for erase done (green light on)."
    time.sleep(8)
    print "wake up"
    #print "Press enter to write data to node " + str(node) + " and test it"
    #sys.stdin.readline()
    cmd = "java Config -c serial@" + DEVICE + ":telosb -m 0 -n " + node
    print cmd
    os.system(cmd)

    #print "\n\n"
    #print "Press enter to re-write node " + str(node)
    #sys.stdin.readline()
    print "sleep for 2 seconds"
    time.sleep(2)
    print "wake up"
    cmd = "make telosb reinstall.1 bsl," + DEVICE
    print cmd
    os.system(cmd)

    #print "\n\n"
    #print "Press enter to test node " + str(node)
    #sys.stdin.readline()
    print "sleep for 2 seconds"
    time.sleep(2)
    print "wake up"
    cmd = "java Config -c serial@" + DEVICE + ":telosb -m 1 -n " + node
    print cmd
    if os.system(cmd) != 0:
        exit(1)

    exit(0)
