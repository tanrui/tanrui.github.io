import java.io.*;
import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;

import jargs.gnu.CmdLineParser;

public class Config implements MessageListener {

     public static final int FEATURE_DIM = 10;
     public static final int MS_GAUSS_SCALES = 10;
     public static final String MODEL_ROOT = "./models";
     public static final int SEND_PERIOD = 32; // in millisecond

     class ms_gauss_model {

	  private int seq;

	  public float h0_mean[];
	  public float h0_ln_det;
	  public float h0_inverse_cov[];
	  public int nsample[];
	  public float mean[][];
	  public float ln_det[];
	  public float inverse_cov[][];

	  public ms_gauss_model() {
	       seq = 0;

	       h0_mean = new float[FEATURE_DIM];
	       h0_inverse_cov = new float[FEATURE_DIM];
	       nsample = new int[MS_GAUSS_SCALES];
	       mean = new float[MS_GAUSS_SCALES][];
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) mean[i] = new float[FEATURE_DIM];
	       ln_det = new float[MS_GAUSS_SCALES];
	       inverse_cov = new float[MS_GAUSS_SCALES][];
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) inverse_cov[i] = new float[FEATURE_DIM];
	  }

	  public boolean equals(ms_gauss_model x) {
	       for(int i = 0; i < FEATURE_DIM; i++) {
		    if (h0_mean[i] != x.h0_mean[i]) return false;
	       }
	       if(h0_ln_det != x.h0_ln_det) return false;
	       for(int i = 0; i < FEATURE_DIM; i++) {
		    if(h0_inverse_cov[i] != x.h0_inverse_cov[i]) return false;
	       }
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) {
		    if(nsample[i] != x.nsample[i]) return false;
	       }
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) {
		    for(int j = 0; j < FEATURE_DIM; j++) {
			 if(mean[i][j] != x.mean[i][j]) return false;
		    }
	       }
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) {
		    if(ln_det[i] != x.ln_det[i]) return false;
	       }
	       for(int i = 0; i < MS_GAUSS_SCALES; i++) {
		    for(int j = 0; j < FEATURE_DIM; j++) {
			 if(inverse_cov[i][j] != x.inverse_cov[i][j]) return false;
		    }
	       }
	       return true;
	  }

	  public boolean update(int data) {
	       if(seq < FEATURE_DIM) {
		    h0_mean[seq] = Float.intBitsToFloat(data);
	       }
	       else if(seq == FEATURE_DIM) {
		    h0_ln_det = Float.intBitsToFloat(data);
	       }
	       else if(seq < (2*FEATURE_DIM + 1)) {
		    h0_inverse_cov[seq - FEATURE_DIM - 1] = Float.intBitsToFloat(data);
	       }
	       else if(seq < (2*FEATURE_DIM + MS_GAUSS_SCALES + 1)) {
		    nsample[seq - 2 * FEATURE_DIM - 1] = data;
	       }
	       else if(seq < (2*FEATURE_DIM + MS_GAUSS_SCALES + FEATURE_DIM * MS_GAUSS_SCALES + 1)) {
		    int i = (seq - 2 * FEATURE_DIM - MS_GAUSS_SCALES - 1) / FEATURE_DIM;
		    int j = (seq - 2 * FEATURE_DIM - MS_GAUSS_SCALES - 1) % FEATURE_DIM;
		    mean[i][j] = Float.intBitsToFloat(data);
	       }
	       else if(seq < (2*FEATURE_DIM + MS_GAUSS_SCALES + FEATURE_DIM * MS_GAUSS_SCALES + MS_GAUSS_SCALES + 1)) {
		    ln_det[seq - 2*FEATURE_DIM - MS_GAUSS_SCALES - FEATURE_DIM * MS_GAUSS_SCALES - 1] = Float.intBitsToFloat(data);
	       }
	       else if(seq < (2*FEATURE_DIM + MS_GAUSS_SCALES + FEATURE_DIM * MS_GAUSS_SCALES + MS_GAUSS_SCALES + FEATURE_DIM * MS_GAUSS_SCALES + 1)) {
		    int i = (seq - 2*FEATURE_DIM - MS_GAUSS_SCALES - FEATURE_DIM * MS_GAUSS_SCALES - MS_GAUSS_SCALES - 1) / FEATURE_DIM;
		    int j = (seq - 2*FEATURE_DIM - MS_GAUSS_SCALES - FEATURE_DIM * MS_GAUSS_SCALES - MS_GAUSS_SCALES - 1) % FEATURE_DIM;
		    inverse_cov[i][j] = Float.intBitsToFloat(data);
	       }
	       else {
		    System.err.println("Overflow.");
		    System.exit(1);
	       }

	       seq ++;

	       if(seq == 241) return true;
	       return false;
	  }
     }

     public static void printf(String msg) { System.err.println(msg); }

     private MoteIF moteIF;

     private ms_gauss_model model;
     private ms_gauss_model rmodel;

     private void syncLoading(boolean sync) {
	  if(!sync) {
	       System.err.println("Get lost when loading the model file.");
	       System.exit(1);
	  }
     }

     private void loadModel(int node) throws Exception {
	  printf("Loading: " + MODEL_ROOT + "/model-d-n" + node + ".txt");
	  FileInputStream fstream = new FileInputStream(MODEL_ROOT + "/model-d-n" + node + ".txt");
	  DataInputStream in = new DataInputStream(fstream);
	  BufferedReader br = new BufferedReader(new InputStreamReader(in));
	  String line;

	  syncLoading(br.readLine().contains("h0_nsample"));
	  br.readLine();
	  syncLoading(br.readLine().contains("h0_mean"));
	  for(int i = 0; i < FEATURE_DIM; i++) {
	       model.h0_mean[i] = Float.parseFloat(br.readLine());
	  }
	  syncLoading(br.readLine().contains("h0_joint_mean"));
	  for(int i = 0; i < (FEATURE_DIM * FEATURE_DIM); i++) br.readLine();
	  syncLoading(br.readLine().contains("h0_cov"));
	  for(int i = 0; i < (FEATURE_DIM * FEATURE_DIM); i++) br.readLine();
	  syncLoading(br.readLine().contains("h0_sample_cov"));
	  for(int i = 0; i < (FEATURE_DIM * FEATURE_DIM); i++) br.readLine();

	  syncLoading(br.readLine().contains("nsample"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       model.nsample[i] = Integer.parseInt(br.readLine());
	  }
	  syncLoading(br.readLine().contains("mean"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < FEATURE_DIM; j++) {
		    model.mean[i][j] = Float.parseFloat(br.readLine());
	       }
	  }
	  syncLoading(br.readLine().contains("joint_mean"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < (FEATURE_DIM * FEATURE_DIM); j++) {
		    br.readLine();
	       }
	  }
	  syncLoading(br.readLine().contains("cov"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < (FEATURE_DIM * FEATURE_DIM); j++) {
		    br.readLine();
	       }
	  }
	  syncLoading(br.readLine().contains("sample_cov"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < (FEATURE_DIM * FEATURE_DIM); j++) {
		    br.readLine();
	       }
	  }

	  syncLoading(br.readLine().contains("h0_ln_det"));
	  model.h0_ln_det = Float.parseFloat(br.readLine());

	  syncLoading(br.readLine().contains("h0_inverse_cov"));
	  for(int i = 0; i < FEATURE_DIM; i++) {
	       for(int j = 0; j < FEATURE_DIM; j++) {
		    line = br.readLine();
		    if(i == j) model.h0_inverse_cov[i] = Float.parseFloat(line);
	       }
	  }
	  
	  syncLoading(br.readLine().contains("ln_det"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       model.ln_det[i] = Float.parseFloat(br.readLine());
	  }

	  syncLoading(br.readLine().contains("inverse_cov"));
	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < FEATURE_DIM; j++) {
		    for(int k = 0; k < FEATURE_DIM; k++) {
			 line = br.readLine();
			 if(j == k) model.inverse_cov[i][j] = Float.parseFloat(line);
		    }
	       }
	  }

	  br.close();
	  in.close();
	  fstream.close();	  
     }

     public void sendModel() throws Exception {
	  ConfigMsg payload = new ConfigMsg();
	  int seq = 0;

	  for(int i = 0; i < FEATURE_DIM; i++) {
	       payload.set_x(seq++);
	       payload.set_y(Float.floatToIntBits(model.h0_mean[i]));
	       moteIF.send(0, payload);
	       Thread.sleep(SEND_PERIOD);
	  }
	  
	  payload.set_x(seq++);
	  payload.set_y(Float.floatToIntBits(model.h0_ln_det));
	  moteIF.send(0, payload);
	  Thread.sleep(SEND_PERIOD);

	  for(int i = 0; i < FEATURE_DIM; i++) {
	       payload.set_x(seq++);
	       payload.set_y(Float.floatToIntBits(model.h0_inverse_cov[i]));
	       moteIF.send(0, payload);
	       Thread.sleep(SEND_PERIOD);
	  }

	  for(int i = 0; i < FEATURE_DIM; i++) {
	       payload.set_x(seq++);
	       payload.set_y(model.nsample[i]);
	       moteIF.send(0, payload);
	       Thread.sleep(SEND_PERIOD);
	  }

	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < FEATURE_DIM; j++) {
		    payload.set_x(seq++);
		    payload.set_y(Float.floatToIntBits(model.mean[i][j]));
		    moteIF.send(0, payload);
		    Thread.sleep(SEND_PERIOD);
	       }
	  }

	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       payload.set_x(seq++);
	       payload.set_y(Float.floatToIntBits(model.ln_det[i]));
	       moteIF.send(0, payload);
	       Thread.sleep(SEND_PERIOD);
	  }

	  for(int i = 0; i < MS_GAUSS_SCALES; i++) {
	       for(int j = 0; j < FEATURE_DIM; j++) {
		    payload.set_x(seq++);
		    payload.set_y(Float.floatToIntBits(model.inverse_cov[i][j]));
		    moteIF.send(0, payload);
		    Thread.sleep(SEND_PERIOD);
	       }
	  }
     }

     public Config(MoteIF moteIF, int node) throws Exception {
	  this.moteIF = moteIF;
	  this.model = new ms_gauss_model();
	  this.rmodel = new ms_gauss_model();
	  loadModel(node);
	  this.moteIF.registerListener(new ConfigMsg(), this);
     }

     public void messageReceived(int to, Message message) {
	  ConfigMsg msg = (ConfigMsg) message;
	  //printf(msg.get_x() + "");
	  //printf(msg.get_y() + "");
	  //printf(Float.intBitsToFloat(msg.get_y()) + "");
	  //printf("");
	  
	  if(rmodel.update(msg.get_y())) {
	       if(model.equals(rmodel)) {
		    printf("test success.");
		    System.exit(0);
	       }
	       else {
		    printf("test fail.");
		    System.exit(1);
	       }
	  }
     }

     public void startRead() throws Exception {
	  ReadMsg payload = new ReadMsg();
	  moteIF.send(0, payload);
     }

     public static void usage() {
	  System.err.println("Usage: java Config\n" +
			     "[{-h, --help}]                                 display this message\n" +
			     "{-c, --comm} serial@/dev/ttyUSBx:telosb        set the link address\n" +
			     "{-m, --mode} 0/1                               0: write mode; 1: read mode\n" +
                             "{-n, --node} nodeid                            set nodeid\n");
     }

     public static void main(String[] args) throws Exception {

	  CmdLineParser parser = new CmdLineParser();
	  CmdLineParser.Option opt_comm = parser.addStringOption('c', "comm");
	  CmdLineParser.Option opt_mode = parser.addIntegerOption('m', "mode");
	  CmdLineParser.Option opt_node = parser.addIntegerOption('n', "node");
	  CmdLineParser.Option opt_help = parser.addBooleanOption('h', "help");

	  try {
	       parser.parse(args);
	  }
	  catch(CmdLineParser.OptionException e) {
	       System.err.println(e.getMessage());
	       usage();
	       System.exit(1);
	  }

	  Boolean help = (Boolean) parser.getOptionValue(opt_help);
	  if(help != null && help == true) {
	       usage();
	       System.exit(0);
	  }

	  String source = (String) parser.getOptionValue(opt_comm);
	  Integer mode = (Integer) parser.getOptionValue(opt_mode);
	  Integer node = (Integer) parser.getOptionValue(opt_node);
	  
	  if(source == null || mode == null || node == null) {
	       System.err.println("missing options.");
	       usage();
	       System.exit(1);
	  }	  

	  PhoenixSource phoenix = BuildSource.makePhoenix(source, PrintStreamMessenger.err);	  
	  MoteIF mif = new ReliableMoteIF(phoenix);
	  Config config = new Config(mif, node);

	  if(mode == 0) {
	       config.sendModel();
	       printf("Done.");
	       System.exit(0);
	  }

	  else if(mode == 1) {
	       config.startRead();
	  }
     }
}
