#!/usr/bin/python

import os
import sys

if __name__ == "__main__":
    node = sys.argv[1]
    device = sys.argv[2]
    os.chdir("./testbed-data")
    if os.system("./install.py " + node + " " + device) != 0:
        raise Exception("Fails to verify the data trace in mote's flash.")

    os.chdir("../testbed-config")
    if os.system("./install.py " + node + " " + device) != 0:
        raise Exception("Fails to verify the model in mote's flash.")

    os.chdir("../testbed-detect")
    cmd = "make telosb reinstall." + node + " bsl," + device
    os.system(cmd)

    os.chdir("../")

    exit(0)
